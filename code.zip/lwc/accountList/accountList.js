import { LightningElement, wire, track } from 'lwc';
import getAccounts from '@salesforce/apex/AccountController.getAccounts';
import updateAccounts from '@salesforce/apex/AccountController.updateAccounts';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecordNotifyChange } from 'lightning/uiRecordApi';


// Datatable Columns
const COLUMNS = [
    { label: 'Account Name',fieldName: 'account_Name',type: 'url',sortable: "true" , typeAttributes: { label: { fieldName: 'Name' }, target: '_blank' } }, 
    { label: 'Owner Name',  fieldName: 'ownerName',type: 'text',sortable: "true" }, 
    { label: 'Phone', fieldName: 'phone',type: 'phone',editable: 'true'},
    { label: 'Website', fieldName: 'website', type: 'url',editable : "true" },
    { label: 'Annual Revenue', fieldName: 'annualRevenue', type: 'currency',editable : "true" },
   
];

export default class AccountList extends LightningElement {
    
    @track records;
    @track cols = COLUMNS;
    @track sortBy;
    @track sortDirection;
    draftValues = [];
    wiredRecords;
    _allData;
    @wire(getAccounts)
    wiredAccount( value ) {
        this.wiredRecords = value; // track the provisioned value
        const { data, error } = value;

        if ( data ) {         
            let currentData = [];
            data.forEach((row) => {

                let rowData = {};
                rowData.Id = row.Id; 
                rowData.account_Name = '/' + row.Id;
                rowData.Name = row.Name;
                rowData.ownerName = row.Owner.Name;
                rowData.phone = row.Phone;
                rowData.website = row.Website;
                rowData.annualRevenue = row.AnnualRevenue;
                
                currentData.push(rowData);
            });
            this._allData = currentData;
            this.records = currentData;
            this.error = undefined;
        } else {
            this.error = error;
            this.records = undefined;
        }

    } 

    handleSortAccountData(event) {       
        this.sortBy = event.detail.fieldName;       
        this.sortDirection = event.detail.sortDirection;       
        this.sortAccountData(event.detail.fieldName, event.detail.sortDirection);
    }

    sortAccountData(fieldname, direction) {
        
        let parseData = JSON.parse(JSON.stringify(this.records));
       
        let keyValue = (a) => {
            return a[fieldname];
        };

       let isReverse = direction === 'asc' ? 1: -1;

           parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : ''; 
            y = keyValue(y) ? keyValue(y) : '';
           
            return isReverse * ((x > y) - (y > x));
        });
        
        this.records = parseData;
    }

    async handleSave(event) {
        const updatedFields = event.detail.draftValues;  
         console.log('updatedFields -' ,updatedFields);

        try {
            // Pass edited fields to the updateContacts Apex controller
            const result = await updateAccounts({data: updatedFields});
            console.log(JSON.stringify("Apex update result: "+ result));
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Account(s) updated',
                    variant: 'success'
                })
            );
    
            // Display fresh data in the datatable
            refreshApex(this.wiredRecords).then(() => {
                // Clear all draft values in the datatable
                this.draftValues = [];
            });
       } catch(error) {
               this.dispatchEvent(
                   new ShowToastEvent({
                       title: 'Error updating or refreshing records',
                       message: error.body.message,
                       variant: 'error'
                   })
             );
        }
    }

    updateSearch(event) {
        var regex = new RegExp(event.target.value,'gi')
        this.records = this._allData.filter(
            row => regex.test(row.Name)
        );
    }

}

